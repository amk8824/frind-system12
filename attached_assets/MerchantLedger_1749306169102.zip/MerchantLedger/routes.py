from flask import render_template, request, jsonify, redirect, url_for, flash
from app import app, db
from models import Record, Payment, Withdrawal, MerchantSummary, Partner, PartnerTransaction, PartnerSummary
from datetime import datetime, date
from sqlalchemy import func, desc

@app.route('/')
def index():
    """الصفحة الرئيسية"""
    # حساب الإحصائيات العامة
    total_records = Record.query.count()
    total_gross_profit = db.session.query(func.sum(Record.my_profit + Record.addition - Record.returned)).scalar() or 0.0
    total_merchant_debt = db.session.query(func.sum(Record.fees + Record.advance)).scalar() or 0.0
    total_withdrawals = db.session.query(func.sum(Withdrawal.amount)).scalar() or 0.0
    total_payments = db.session.query(func.sum(Payment.amount)).scalar() or 0.0
    
    available_balance = total_gross_profit - total_withdrawals
    final_net_profit = total_gross_profit - total_withdrawals
    actual_debt = total_merchant_debt - total_payments
    
    stats = {
        'total_records': total_records,
        'total_gross_profit': total_gross_profit,
        'total_merchant_debt': actual_debt,
        'total_withdrawals': total_withdrawals,
        'available_balance': available_balance,
        'final_net_profit': final_net_profit
    }
    
    return render_template('index.html', stats=stats)

@app.route('/save_record', methods=['POST'])
def save_record():
    """حفظ سجل جديد"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        if not data.get('merchant_name') or not data.get('date'):
            return jsonify({'success': False, 'message': 'يرجى إدخال اسم التاجر والتاريخ على الأقل'})
        
        # تحويل التاريخ
        record_date = datetime.strptime(data['date'], '%Y-%m-%d').date()
        
        # إنشاء السجل الجديد
        record = Record(
            merchant_name=data['merchant_name'].strip(),
            foreign_driver=data.get('foreign_driver', '').strip(),
            foreign_car=data.get('foreign_car', '').strip(),
            local_driver=data.get('local_driver', '').strip(),
            local_car=data.get('local_car', '').strip(),
            date=record_date,
            goods_type=data.get('goods_type', '').strip(),
            notes=data.get('notes', '').strip(),
            fees=float(data.get('fees', 0)),
            advance=float(data.get('advance', 0)),
            my_profit=float(data.get('my_profit', 0)),
            addition=float(data.get('addition', 0)),
            returned=float(data.get('returned', 0))
        )
        
        db.session.add(record)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'تم حفظ السجل بنجاح!'})
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error saving record: {str(e)}")
        return jsonify({'success': False, 'message': f'خطأ في حفظ السجل: {str(e)}'})

@app.route('/get_records')
def get_records():
    """جلب جميع السجلات"""
    records = Record.query.order_by(Record.date.desc()).all()
    
    records_data = []
    for record in records:
        records_data.append({
            'id': record.id,
            'merchant_name': record.merchant_name,
            'foreign_driver': record.foreign_driver,
            'foreign_car': record.foreign_car,
            'local_driver': record.local_driver,
            'local_car': record.local_car,
            'date': record.date.strftime('%Y-%m-%d'),
            'goods_type': record.goods_type,
            'notes': record.notes,
            'fees': record.fees,
            'advance': record.advance,
            'my_profit': record.my_profit,
            'addition': record.addition,
            'returned': record.returned,
            'total_debt': record.total_debt,
            'net_profit': record.net_profit
        })
    
    return jsonify(records_data)

@app.route('/get_merchants_debts')
def get_merchants_debts():
    """جلب ديون التجار"""
    merchants = MerchantSummary.get_all_merchants()
    return jsonify(merchants)

@app.route('/get_merchant_statement/<merchant_name>')
def get_merchant_statement(merchant_name):
    """جلب كشف حساب تاجر معين"""
    transactions = MerchantSummary.get_merchant_transactions(merchant_name)
    payments = MerchantSummary.get_merchant_payments(merchant_name)
    current_balance = MerchantSummary.get_merchant_balance(merchant_name)
    
    # تحويل البيانات للإرسال
    transactions_data = []
    for t in transactions:
        transactions_data.append({
            'id': t.id,
            'date': t.date.strftime('%Y-%m-%d'),
            'goods_type': t.goods_type,
            'fees': t.fees,
            'advance': t.advance,
            'my_profit': t.my_profit,
            'addition': t.addition,
            'returned': t.returned,
            'total_debt': t.total_debt,
            'net_profit': t.net_profit,
            'notes': t.notes
        })
    
    payments_data = []
    for p in payments:
        payments_data.append({
            'id': p.id,
            'payment_date': p.payment_date.strftime('%Y-%m-%d'),
            'amount': p.amount,
            'balance_before': p.balance_before,
            'balance_after': p.balance_after,
            'notes': p.notes
        })
    
    return jsonify({
        'merchant_name': merchant_name,
        'transactions': transactions_data,
        'payments': payments_data,
        'current_balance': current_balance
    })

@app.route('/add_payment', methods=['POST'])
def add_payment():
    """إضافة تسديد جديد"""
    try:
        data = request.get_json()
        
        merchant_name = data['merchant_name'].strip()
        amount = float(data['amount'])
        payment_date = datetime.strptime(data['payment_date'], '%Y-%m-%d').date()
        notes = data.get('notes', '').strip()
        
        # حساب الرصيد قبل التسديد
        balance_before = MerchantSummary.get_merchant_balance(merchant_name)
        balance_after = balance_before - amount
        
        # إنشاء التسديد
        payment = Payment(
            merchant_name=merchant_name,
            amount=amount,
            payment_date=payment_date,
            balance_before=balance_before,
            balance_after=balance_after,
            notes=notes
        )
        
        db.session.add(payment)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'تم إضافة التسديد بنجاح!'})
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error adding payment: {str(e)}")
        return jsonify({'success': False, 'message': f'خطأ في إضافة التسديد: {str(e)}'})

@app.route('/add_withdrawal', methods=['POST'])
def add_withdrawal():
    """إضافة سحب جديد"""
    try:
        data = request.get_json()
        
        amount = float(data['amount'])
        reason = data['reason'].strip()
        withdrawal_date = datetime.strptime(data['withdrawal_date'], '%Y-%m-%d').date()
        
        # التحقق من الرصيد المتاح
        total_gross_profit = db.session.query(func.sum(Record.my_profit + Record.addition - Record.returned)).scalar() or 0.0
        total_withdrawals = db.session.query(func.sum(Withdrawal.amount)).scalar() or 0.0
        available_balance = total_gross_profit - total_withdrawals
        
        if amount > available_balance:
            return jsonify({'success': False, 'message': 'المبلغ المطلوب سحبه أكبر من الرصيد المتاح'})
        
        # إنشاء السحب
        withdrawal = Withdrawal(
            amount=amount,
            reason=reason,
            withdrawal_date=withdrawal_date
        )
        
        db.session.add(withdrawal)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'تم إضافة السحب بنجاح!'})
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error adding withdrawal: {str(e)}")
        return jsonify({'success': False, 'message': f'خطأ في إضافة السحب: {str(e)}'})

@app.route('/get_withdrawals')
def get_withdrawals():
    """جلب جميع السحوبات"""
    withdrawals = Withdrawal.query.order_by(Withdrawal.withdrawal_date.desc()).all()
    
    withdrawals_data = []
    for w in withdrawals:
        withdrawals_data.append({
            'id': w.id,
            'amount': w.amount,
            'reason': w.reason,
            'withdrawal_date': w.withdrawal_date.strftime('%Y-%m-%d'),
            'created_at': w.created_at.strftime('%Y-%m-%d %H:%M')
        })
    
    return jsonify(withdrawals_data)

@app.route('/delete_withdrawal/<int:withdrawal_id>', methods=['DELETE'])
def delete_withdrawal(withdrawal_id):
    """حذف سحب"""
    try:
        withdrawal = Withdrawal.query.get_or_404(withdrawal_id)
        db.session.delete(withdrawal)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'تم حذف السحب بنجاح!'})
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error deleting withdrawal: {str(e)}")
        return jsonify({'success': False, 'message': f'خطأ في حذف السحب: {str(e)}'})

@app.route('/get_stats')
def get_stats():
    """جلب الإحصائيات المحدثة"""
    total_records = Record.query.count()
    total_gross_profit = db.session.query(func.sum(Record.my_profit + Record.addition - Record.returned)).scalar() or 0.0
    total_merchant_debt = db.session.query(func.sum(Record.fees + Record.advance)).scalar() or 0.0
    total_withdrawals = db.session.query(func.sum(Withdrawal.amount)).scalar() or 0.0
    total_payments = db.session.query(func.sum(Payment.amount)).scalar() or 0.0
    
    available_balance = total_gross_profit - total_withdrawals
    final_net_profit = total_gross_profit - total_withdrawals
    actual_debt = total_merchant_debt - total_payments
    
    # إضافة إحصائيات الشراكة
    profits_data = PartnerSummary.get_total_profits()
    
    return jsonify({
        'total_records': total_records,
        'total_gross_profit': total_gross_profit,
        'total_merchant_debt': actual_debt,
        'total_withdrawals': total_withdrawals,
        'available_balance': available_balance,
        'final_net_profit': final_net_profit,
        'distributable_profit': profits_data['distributable_profit']
    })

# طرق الشراكة
@app.route('/get_partners')
def get_partners():
    """جلب جميع الشركاء مع أرصدتهم"""
    partners_summary = PartnerSummary.get_all_partners_summary()
    return jsonify(partners_summary)

@app.route('/get_partner_statement/<partner_name>')
def get_partner_statement(partner_name):
    """جلب كشف حساب شريك معين"""
    # معلومات الشريك
    partner_summary = PartnerSummary.calculate_partner_share(partner_name)
    
    # معاملات الشريك
    transactions = PartnerSummary.get_partner_transactions(partner_name)
    
    transactions_data = []
    for t in transactions:
        transactions_data.append({
            'id': t.id,
            'amount': t.amount,
            'transaction_type': t.transaction_type,
            'transaction_date': t.transaction_date.strftime('%Y-%m-%d'),
            'description': t.description,
            'balance_before': t.balance_before,
            'balance_after': t.balance_after,
            'created_at': t.created_at.strftime('%Y-%m-%d %H:%M')
        })
    
    return jsonify({
        'partner_summary': partner_summary,
        'transactions': transactions_data
    })

@app.route('/add_partner_transaction', methods=['POST'])
def add_partner_transaction():
    """إضافة معاملة جديدة للشريك"""
    try:
        data = request.get_json()
        
        partner_name = data['partner_name']
        amount = float(data['amount'])
        transaction_type = data['transaction_type']  # 'withdrawal' أو 'deposit'
        transaction_date = datetime.strptime(data['transaction_date'], '%Y-%m-%d').date()
        description = data.get('description', '').strip()
        
        # التحقق من وجود الشريك
        partner = Partner.query.filter_by(name=partner_name).first()
        if not partner:
            return jsonify({'success': False, 'message': 'الشريك غير موجود'})
        
        # إضافة المعاملة
        transaction = PartnerSummary.add_partner_transaction(
            partner_name, amount, transaction_type, transaction_date, description
        )
        
        transaction_label = 'سحب' if transaction_type == 'withdrawal' else 'إيداع'
        return jsonify({'success': True, 'message': f'تم إضافة {transaction_label} بنجاح!'})
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error adding partner transaction: {str(e)}")
        return jsonify({'success': False, 'message': f'خطأ في إضافة المعاملة: {str(e)}'})

@app.route('/delete_partner_transaction/<int:transaction_id>', methods=['DELETE'])
def delete_partner_transaction(transaction_id):
    """حذف معاملة شريك"""
    try:
        transaction = PartnerTransaction.query.get_or_404(transaction_id)
        db.session.delete(transaction)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'تم حذف المعاملة بنجاح!'})
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error deleting partner transaction: {str(e)}")
        return jsonify({'success': False, 'message': f'خطأ في حذف المعاملة: {str(e)}'})

@app.route('/get_profits_distribution')
def get_profits_distribution():
    """جلب توزيع الأرباح على الشركاء"""
    profits_data = PartnerSummary.get_total_profits()
    partners_summary = PartnerSummary.get_all_partners_summary()
    
    return jsonify({
        'profits_data': profits_data,
        'partners_summary': partners_summary
    })
