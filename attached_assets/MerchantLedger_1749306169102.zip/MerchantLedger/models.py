from app import db
from datetime import datetime
from sqlalchemy import func

class Record(db.Model):
    """نموذج سجل المعاملات المحاسبية"""
    id = db.Column(db.Integer, primary_key=True)
    merchant_name = db.Column(db.String(200), nullable=False, index=True)
    foreign_driver = db.Column(db.String(200))
    foreign_car = db.Column(db.String(100))
    local_driver = db.Column(db.String(200))
    local_car = db.Column(db.String(100))
    date = db.Column(db.Date, nullable=False, index=True)
    goods_type = db.Column(db.String(200))
    notes = db.Column(db.Text)
    fees = db.Column(db.Float, default=0.0)  # الأجور
    advance = db.Column(db.Float, default=0.0)  # السلف
    my_profit = db.Column(db.Float, default=0.0)  # التخليص
    addition = db.Column(db.Float, default=0.0)  # الإضافة
    returned = db.Column(db.Float, default=0.0)  # الراجع
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    @property
    def total_debt(self):
        """إجمالي الديون (أجور + سلف)"""
        return self.fees + self.advance
    
    @property
    def net_profit(self):
        """صافي الربح (تخليص + إضافة - راجع)"""
        return self.my_profit + self.addition - self.returned

class Payment(db.Model):
    """نموذج تسديدات التجار"""
    id = db.Column(db.Integer, primary_key=True)
    merchant_name = db.Column(db.String(200), nullable=False, index=True)
    amount = db.Column(db.Float, nullable=False)
    payment_date = db.Column(db.Date, nullable=False)
    balance_before = db.Column(db.Float, nullable=False)  # الرصيد قبل التسديد
    balance_after = db.Column(db.Float, nullable=False)   # الرصيد بعد التسديد
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Withdrawal(db.Model):
    """نموذج السحوبات الخارجية"""
    id = db.Column(db.Integer, primary_key=True)
    amount = db.Column(db.Float, nullable=False)
    reason = db.Column(db.String(500), nullable=False)
    withdrawal_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Partner(db.Model):
    """نموذج الشركاء"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    percentage = db.Column(db.Float, nullable=False)  # نسبة الشراكة
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class PartnerTransaction(db.Model):
    """نموذج معاملات الشركاء (سحب وإيداع)"""
    id = db.Column(db.Integer, primary_key=True)
    partner_name = db.Column(db.String(100), nullable=False, index=True)
    amount = db.Column(db.Float, nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False)  # 'withdrawal' أو 'deposit'
    transaction_date = db.Column(db.Date, nullable=False)
    description = db.Column(db.Text)
    balance_before = db.Column(db.Float, nullable=False)
    balance_after = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class MerchantSummary:
    """كلاس مساعد لحساب ملخص التاجر"""
    
    @staticmethod
    def get_merchant_balance(merchant_name):
        """حساب رصيد التاجر الحالي"""
        # حساب إجمالي الديون من السجلات
        total_debt = db.session.query(func.sum(Record.fees + Record.advance)).filter(
            Record.merchant_name == merchant_name
        ).scalar() or 0.0
        
        # حساب إجمالي التسديدات
        total_payments = db.session.query(func.sum(Payment.amount)).filter(
            Payment.merchant_name == merchant_name
        ).scalar() or 0.0
        
        return total_debt - total_payments
    
    @staticmethod
    def get_merchant_transactions(merchant_name):
        """جلب جميع معاملات التاجر"""
        return Record.query.filter_by(merchant_name=merchant_name).order_by(Record.date.desc()).all()
    
    @staticmethod
    def get_merchant_payments(merchant_name):
        """جلب جميع تسديدات التاجر"""
        return Payment.query.filter_by(merchant_name=merchant_name).order_by(Payment.payment_date.desc()).all()
    
    @staticmethod
    def get_all_merchants():
        """جلب قائمة بجميع التجار مع ملخص حساباتهم"""
        merchants = db.session.query(Record.merchant_name).distinct().all()
        result = []
        
        for merchant_tuple in merchants:
            merchant_name = merchant_tuple[0]
            
            # حساب الإحصائيات
            transactions = Record.query.filter_by(merchant_name=merchant_name).all()
            payments = Payment.query.filter_by(merchant_name=merchant_name).all()
            
            total_transactions = len(transactions)
            total_fees = sum(t.fees for t in transactions)
            total_advance = sum(t.advance for t in transactions)
            total_debt = total_fees + total_advance
            total_payments = sum(p.amount for p in payments)
            current_balance = total_debt - total_payments
            
            last_transaction = max([t.date for t in transactions]) if transactions else None
            last_payment = max([p.payment_date for p in payments]) if payments else None
            
            result.append({
                'name': merchant_name,
                'transaction_count': total_transactions,
                'total_fees': total_fees,
                'total_advance': total_advance,
                'total_debt': total_debt,
                'total_payments': total_payments,
                'current_balance': current_balance,
                'last_transaction': last_transaction,
                'last_payment': last_payment
            })
        
        return sorted(result, key=lambda x: x['current_balance'], reverse=True)

class PartnerSummary:
    """كلاس مساعد لحساب أرصدة الشركاء"""
    
    @staticmethod
    def initialize_partners():
        """تهيئة الشركاء في قاعدة البيانات"""
        partners_data = [
            ('صديق', 20.0),
            ('محمد', 20.0),
            ('زياد', 20.0),
            ('مؤيد', 12.0),
            ('عمر', 10.0),
            ('صالح', 8.0),
            ('ايمن', 8.0),
            ('سلوان', 2.0)
        ]
        
        for name, percentage in partners_data:
            existing_partner = Partner.query.filter_by(name=name).first()
            if not existing_partner:
                partner = Partner()
                partner.name = name
                partner.percentage = percentage
                db.session.add(partner)
        
        db.session.commit()
    
    @staticmethod
    def get_total_profits():
        """حساب إجمالي الأرباح القابلة للتوزيع"""
        # إجمالي أرباح التخليص
        total_clearance_profit = db.session.query(func.sum(Record.my_profit + Record.addition - Record.returned)).scalar() or 0.0
        
        # إجمالي السحوبات الخارجية
        total_external_withdrawals = db.session.query(func.sum(Withdrawal.amount)).scalar() or 0.0
        
        # الأرباح الصافية القابلة للتوزيع
        distributable_profit = total_clearance_profit - total_external_withdrawals
        
        return {
            'total_clearance_profit': total_clearance_profit,
            'total_external_withdrawals': total_external_withdrawals,
            'distributable_profit': distributable_profit
        }
    
    @staticmethod
    def calculate_partner_share(partner_name):
        """حساب حصة شريك معين"""
        partner = Partner.query.filter_by(name=partner_name).first()
        if not partner:
            return {
                'partner_name': partner_name,
                'percentage': 0.0,
                'theoretical_share': 0.0,
                'withdrawals': 0.0,
                'deposits': 0.0,
                'current_balance': 0.0
            }
        
        profits = PartnerSummary.get_total_profits()
        partner_theoretical_share = profits['distributable_profit'] * (partner.percentage / 100)
        
        # حساب إجمالي السحوبات والإيداعات للشريك
        withdrawals = db.session.query(func.sum(PartnerTransaction.amount)).filter(
            PartnerTransaction.partner_name == partner_name,
            PartnerTransaction.transaction_type == 'withdrawal'
        ).scalar() or 0.0
        
        deposits = db.session.query(func.sum(PartnerTransaction.amount)).filter(
            PartnerTransaction.partner_name == partner_name,
            PartnerTransaction.transaction_type == 'deposit'
        ).scalar() or 0.0
        
        # الرصيد الحالي = الحصة النظرية - السحوبات + الإيداعات
        current_balance = partner_theoretical_share - withdrawals + deposits
        
        return {
            'partner_name': partner_name,
            'percentage': partner.percentage,
            'theoretical_share': partner_theoretical_share,
            'withdrawals': withdrawals,
            'deposits': deposits,
            'current_balance': current_balance
        }
    
    @staticmethod
    def get_all_partners_summary():
        """جلب ملخص جميع الشركاء"""
        partners = Partner.query.all()
        result = []
        
        for partner in partners:
            summary = PartnerSummary.calculate_partner_share(partner.name)
            result.append(summary)
        
        return result
    
    @staticmethod
    def get_partner_transactions(partner_name):
        """جلب جميع معاملات الشريك"""
        return PartnerTransaction.query.filter_by(partner_name=partner_name).order_by(PartnerTransaction.transaction_date.desc()).all()
    
    @staticmethod
    def add_partner_transaction(partner_name, amount, transaction_type, transaction_date, description=''):
        """إضافة معاملة جديدة للشريك"""
        # حساب الرصيد قبل المعاملة
        current_summary = PartnerSummary.calculate_partner_share(partner_name)
        balance_before = current_summary['current_balance']
        
        # حساب الرصيد بعد المعاملة
        if transaction_type == 'withdrawal':
            balance_after = balance_before - amount
        else:  # deposit
            balance_after = balance_before + amount
        
        # إنشاء المعاملة
        transaction = PartnerTransaction()
        transaction.partner_name = partner_name
        transaction.amount = amount
        transaction.transaction_type = transaction_type
        transaction.transaction_date = transaction_date
        transaction.description = description
        transaction.balance_before = balance_before
        transaction.balance_after = balance_after
        
        db.session.add(transaction)
        db.session.commit()
        
        return transaction
